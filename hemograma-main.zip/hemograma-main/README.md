# hemograma
O objetivo deste projeto é fazer com que as empresas que trabalham com análise de sangue possam oferecer aos clientes uma análise de seus exames criando um aplicativo onde os mesmos poderão carregar o pdf e receber uma análise do exame de sangue feito por uma A.I
